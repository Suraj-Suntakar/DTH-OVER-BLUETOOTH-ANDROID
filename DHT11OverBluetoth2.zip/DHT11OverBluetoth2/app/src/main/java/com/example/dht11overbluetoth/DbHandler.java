package com.example.dht11overbluetoth;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class DbHandler extends SQLiteOpenHelper {

    public static final int DB_VERSION = 1;
    public static final String DB_NAME = "TempHumid";
    public static final String TBL_NAME = "temphumid";
    public static final String ID = "id";
    public static final String TEMP_HUMID_DATA = "tempHumidData";

    public DbHandler(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE " + TBL_NAME +" (" + ID + " INTEGER PRIMARY KEY, " + TEMP_HUMID_DATA +" TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){}

    public void addTH(String data){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(TEMP_HUMID_DATA, data);
        db.insert(TBL_NAME, null, cv);
        db.close();
    }

    public Cursor getAllData(){
        SQLiteDatabase db = getReadableDatabase();
        Cursor res = db.rawQuery("SELECT * FROM " + TBL_NAME, null);
        return res;
    }

}
